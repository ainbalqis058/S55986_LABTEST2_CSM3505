package com.example.android.s55986_labtest_2

import android.content.Context
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var username = ArrayList<String>()

        if(!dbExists(this,"mydata")) {
            createDB();
        }

        val db = openOrCreateDatabase("mydata",MODE_PRIVATE,null)
        val sql = "SELECT username from mydata"
        val c: Cursor = db.rawQuery(sql,null)
        while (c.moveToNext()){
            val usrname = c.getString(0)
            username.add(usrname)
        }
        c.close()

        val btnSave = findViewById<ImageButton>(R.id.btnSave)
        btnSave.setOnClickListener(){
            val username = findViewById<EditText>(R.id.inUsername)
            val password = findViewById<EditText>(R.id.inPassword)

            //check empty ke tak
            /*if  (entiti.text.isEmpty()){
                subToast("Entiti must not empty!")
            }

            if  (username.text.isEmpty()){
                subToast("Username must not empty!")
            } */

            val emptyLevel = emptiness(username, password)
            if(emptyLevel >0){
                //which field is empty
                when(emptyLevel){

                    6 -> subToast("Username must not empty!")
                    7 -> subToast("Password must not empty!")
                    13 -> subToast("Username and Password must not empty!")

                }
            }else{
                //check for exist entiti
                val status = checkKey(username.text.toString())
                val uname = username.text.toString()
                val passwd = password.text.toString()
                if(!status){
                    val db = openOrCreateDatabase("mydata", MODE_PRIVATE,null)
                    val sql = "SELECT username, password from user where username='$uname';"
                    db.execSQL(sql)
                    subToast("Username $uname sucessful login!")
                    val intent = Intent(this,MainActivity::class.java).apply{

                    }
                    startActivity(intent)

                }else{
                    subToast("Username already exists inside Database!")
                }
            }

        }


    }


    private fun dbExists(c: Context, dbName: String): Boolean {
        val dbFile: File = c.getDatabasePath(dbName)
        return dbFile.exists()
    }

    private fun createDB() {
        val db = openOrCreateDatabase("mydata", AppCompatActivity.MODE_PRIVATE, null)
        subToast("Database mydata created!")
        val sqlText = "CREATE TABLE IF NOT EXISTS user " +
                "username VARCHAR(30) NOT NULL, " +
                "password VARCHAR(30) NOT NULL " +
                ");"
        db.execSQL(sqlText)
        var nextSQL =
            "INSERT INTO mydata (username,password) VALUES ('ahmad','ahmad1234');"
        db.execSQL(nextSQL)

        subToast("1 sample username added")
    }

    private fun subToast(msg: String) {

        Toast.makeText( this,msg, Toast.LENGTH_SHORT).show()
    }

    private fun checkKey(username:String):Boolean{
        val db = openOrCreateDatabase("mydata", MODE_PRIVATE,null)
        val sql = "select * from user where username ='$username'"
        val cursor = db.rawQuery(sql, null)
        var out=false
        if (cursor.count > 0)
            out=true
        return out
    }

    private fun emptiness(username:EditText, password:EditText):Int{
        var empty = 0

        if(username.text.isEmpty())
            empty+=6

        if (password.text.isEmpty())
            empty+=7

        return empty
    }

}